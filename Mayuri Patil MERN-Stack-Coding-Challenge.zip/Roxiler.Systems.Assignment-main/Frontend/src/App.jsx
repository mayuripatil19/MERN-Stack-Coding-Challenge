import Table from "./components/Table"

const App = () => {
  return (

    <div>
      <Table />
    </div>
  )


}

export default App